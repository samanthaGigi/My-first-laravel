<?php $__env->startSection("content"); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <div class="container">
    <div class="row">
        <br/><br/><br/>
        <div class="col-md-8 col-md-offset-2">
          <div class="list-group">
            <a href="#" class="list-group-item active"><h1>MY SOCIAL MEDIA ACCOUNTS</h1></a>
            <a href="#" class="list-group-item"><i class="fa fa-facebook-square fa-3x" aria-hidden="true"></i><strong style="font-size: 20px;"> Facebook.com/samfvckingigi</strong></a>
            <a href="#" class="list-group-item"><i class="fa fa-instagram fa-3x" aria-hidden="true"></i><strong style="font-size: 20px;"> Instagram.com/samanthagigig</strong></a>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>