<?php $__env->startSection("content"); ?>
  <div class="container">
    <div class="container-fluid">
      <div class="panel panel-info" style="margin-top: 100px;">
        <div class="panel-heading h1">About PHP2 Subject</div>
        <div class="panel-body h3">
          <i>This course provides an overview of the PHP web programming language as a facility in developing dynamic and interactive web applications. Emphasis is on the Model-View-Controller architecture. Topics include PHP web configuration and setup, web forms, user controls, server controls, web services and database integration.</i>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>