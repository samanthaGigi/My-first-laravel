<?php $__env->startSection("content"); ?>   
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <div class="container">
    <div class="row">
        <br/><br/><br/>
        <div class="col-md-8 col-md-offset-2">
        	<ul class="list-group">
            <li class="list-group-item list-group-item-info"><h1>MY EDUCATIONAL BACKGROUND</h1></li>
            <li class="list-group-item"><i class="fa fa-university fa-2x" aria-hidden="true"></i> Elementary : Zapatera Elementary School</li>
            <li class="list-group-item"><i class="fa fa-university fa-2x" aria-hidden="true"></i> Secondary : University of Southern Philippines Foundation</li>
            <li class="list-group-item"><i class="fa fa-university fa-2x" aria-hidden="true"></i> College : University of Cebu (current)</li>
          </ul>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>