@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <br/><br/>
        <div class="col-md-8 col-md-offset-2">
        	<h1><i>ALL ABOUT ME</i></h1><br/>
          <blockquote>
            <p>
              Hi I am Gigi Samantha Yap and here's what I like.<br/><br/>
              I am a person who is positive about every aspect of life. There are many things I like to do, to see, and to experience. I like to read, I like to write. I like to think, I like to dream. I like to talk, I like to listen. I like to see the sunrise in the morning, I like to see the moonlight at night. I like to feel the music flowing on my face, I like to smell the wind coming from the ocean. I like to look at the clouds in the sky with a blank mind, I like to do thought experiment when I cannot sleep in the middle of the night. I like rain in summer. I like to sleep early, I like to get up late. I like to be alone, I like to be surrounded by people. I like country’s peace, I like metropolis’ noise. I like delicious food and comfortable shoes. I like good books and romantic or any movies that fits in my mood. I like the land and the nature, I like people. And, I like to laugh.
            </p>
            <footer>Gigi Samantha</footer>
          </blockquote>
             
        </div>
    </div>
</div>

@stop