@extends('layouts.app2')

@section("content")
<!DOCTYPE html>
<html>
<body>
<div class="container">
    <div class="row">
      	<h1>MY ACADEMIC SCHEDULE</h1>
    	<table class="table table-striped table-hover table-bordered">
    		<thead>
	     			<tr>
    				<th>Subjects</th>
    				<th style="width: 800px;">Subject Description</th>
    				<th>Day Schedule</th>
    				<th>Time</th>
    			</tr>
    		</thead>
    		<tbody>
    			<tr>
    				<td>Physics 2</td>
    				<td>
    					This course deals with the study of the following : Fluids, thermal Expansion; Thermal Stress; Heat Transfer; Wave; Calorimetry; Wave; Electrostatics; Electricity; Magnetism; Optics; Image formation by plane and curve mirrors and Image formation by thins lenses.
    				</td>
    				<td>MWF</td>
    				<td>12:30 - 2:30</td>
    			</tr>
    			<tr>
    				<td>Free Elective Big Data</td>
    				<td>
    					Introduction to Big Data
    				</td>
    				<td>MWF</td>
    				<td>2:30 - 3:30</td>
    			</tr>
    			<tr>
    				<td>Management</td>
    				<td>
    					This course covers the principles and theories of entrepreneurship in technology ventures, which is about commercializing technology ideas into viable enterprises. Emphasis is on lean startup methodology. Topics include idea generation, customer validation, building minimum viable product, business model, and elevator pitch.
    				</td>
    				<td>MWF</td>
    				<td>5:30 - 6:30</td>
    			</tr>
    			<tr>
    				<td>Php2</td>
    				<td>
    					This course provides an overview of the PHP web programming language as a facility in developing dynamic and interactive web applications. Emphasis is on the Model-View-Controller architecture. Topics include PHP web configuration and setup, web forms, user controls, server controls, web services and database integration.
    				</td>
    				<td>MWF</td>
    				<td>6:30 - 8:30</td>
    			</tr>
    			<tr>
    				<td>Free Elective CIS</td>
    				<td>
    					Introduction to Cloud Infrastructure Services
    				</td>
    				<td>TTH</td>
    				<td>3:00 - 4:30</td>
    			</tr>
    			<tr>
    				<td>AIS</td>
    				<td>
    					This course deals with the fundamentals of accounting information system as a major and equally-important component of the computer-based information system. Emphasis is on transaction processing and financial reporting. Topics include enterprise systems, electronic business, IS documentation, IS control, business processes, and reports.
    				</td>
    				<td>TTH</td>
    				<td>6:30 - 8:00</td>
    			</tr>
    		</tbody>
    	</table>      
    </div>
</div>

</body>
</html>
@stop